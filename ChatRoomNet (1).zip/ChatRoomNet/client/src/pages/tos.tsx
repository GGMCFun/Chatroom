import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Scale, Shield, Users, MessageSquare, AlertTriangle } from 'lucide-react';
import { Link } from 'wouter';

export default function TOS() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Link to="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Chat
            </Button>
          </Link>
          
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full mb-4">
              <Scale className="text-blue-600 dark:text-blue-400 text-2xl" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Terms of Service</h1>
            <p className="text-gray-600 dark:text-gray-300">Last updated: {new Date().toLocaleDateString()}</p>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageSquare className="w-5 h-5 text-blue-600" />
                <span>Chat Service Agreement</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700 dark:text-gray-300">
                By using our chat service, you agree to these terms. Our platform provides real-time messaging 
                capabilities for users to communicate in various chat rooms.
              </p>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  <strong>Note:</strong> Nothing you do is stored or shared with anyone.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-green-600" />
                <span>User Conduct</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700 dark:text-gray-300">
                Users are expected to behave somewhat responable and be respectful. Please try not to do the following things:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
                <li>Harassment, bullying, or threatening other users</li>
                <li>Sharing inappropriate, offensive, or explicit content</li>
                <li>Spamming or flooding chat rooms with messages</li>
                <li>Impersonating other users or providing false information</li>
                <li>Attempting to hack, disrupt, or abuse the service</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="w-5 h-5 text-purple-600" />
                <span>Privacy & Data</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700 dark:text-gray-300">
                We are committed to protecting your privacy:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
                <li>Messages are not stored at all</li>
                <li>We do not share your personal information with third parties</li>
                <li>User data is not stored anywhere</li>
             
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
                <span>Service Limitations</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700 dark:text-gray-300">
                Please understand the following limitations:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
                <li>This service is provided "as is" without warranties</li>
                <li>We may temporarily suspend service for maintenance</li>
                <li>Chat history may be cleared periodically</li>
                <li>We reserve the right to do anything we want to the app and your messages inside of the app</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact & Support</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 dark:text-gray-300">
                If you have questions about these terms or need support, please contact us while we are online in the chat room id "Support"
              </p>
            </CardContent>
          </Card>

          <div className="text-center py-8">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              These terms are subject to change. Continued use of the service constitutes acceptance of any updates.
            </p>
            <Link to="/">
              <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                Return to Chat
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}