import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, MessageSquare, X } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface RoomWithUserCount {
  id: string;
  name: string;
  description: string;
  isPrivate: boolean;
  userCount: number;
  activeUsers: string[];
  recentMessages: Array<{
    id: number;
    username: string;
    message: string;
    timestamp: string;
    isAdmin?: boolean;
  }>;
  totalMessages: number;
}

interface RoomManagerProps {
  isAdmin: boolean;
  currentRoomId: string;
  onRoomSwitch: (roomId: string) => void;
}

export default function RoomManager({ isAdmin, currentRoomId, onRoomSwitch }: RoomManagerProps) {
  const [rooms, setRooms] = useState<RoomWithUserCount[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  const fetchRooms = async () => {
    if (!isAdmin) return;
    
    setLoading(true);
    try {
      const response = await fetch('/api/admin/rooms');
      if (response.ok) {
        const roomsData = await response.json();
        setRooms(roomsData);
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Room fetch error:', error);
      toast({
        title: "Error",
        description: `Failed to fetch rooms: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && isAdmin) {
      fetchRooms();
    }
  }, [isOpen, isAdmin]);

  const handleRoomClick = (roomId: string) => {
    if (roomId !== currentRoomId) {
      onRoomSwitch(roomId);
      setIsOpen(false);
    }
  };

  if (!isAdmin) return null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center space-x-2">
          <Users className="h-4 w-4" />
          <span>View All Rooms</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Room Management</DialogTitle>
          <DialogDescription>
            View all chat rooms and their active users
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
              <p className="text-sm text-gray-500 mt-2">Loading rooms...</p>
            </div>
          ) : (
            rooms.map((room) => (
              <Card 
                key={room.id} 
                className={`cursor-pointer transition-all ${
                  room.id === currentRoomId 
                    ? 'ring-2 ring-blue-500 bg-blue-50' 
                    : 'hover:bg-gray-50'
                }`}
                onClick={() => handleRoomClick(room.id)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <CardTitle className="text-lg">{room.name}</CardTitle>
                      {room.id === currentRoomId && (
                        <Badge variant="secondary">Current</Badge>
                      )}
                      {room.isPrivate && (
                        <Badge variant="destructive">Private</Badge>
                      )}
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>{room.userCount}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MessageSquare className="h-4 w-4" />
                        <span>{room.totalMessages}</span>
                      </div>
                    </div>
                  </div>
                  <CardDescription>{room.description}</CardDescription>
                </CardHeader>
                
                <CardContent className="pt-0 space-y-3">
                  {room.activeUsers.length > 0 && (
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-2">Active Users:</p>
                      <div className="flex flex-wrap gap-2">
                        {room.activeUsers.map((username) => (
                          <Badge key={username} variant="outline" className="text-xs">
                            {username}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {room.recentMessages.length > 0 && (
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-2">Recent Messages:</p>
                      <div className="space-y-2 max-h-24 overflow-y-auto">
                        {room.recentMessages.map((msg) => (
                          <div key={msg.id} className="text-xs bg-gray-50 p-2 rounded">
                            <div className="flex items-center space-x-2">
                              <span className={`font-medium ${msg.isAdmin ? 'text-red-600' : 'text-gray-700'}`}>
                                {msg.username}
                                {msg.isAdmin && <span className="text-red-500 ml-1">(Admin)</span>}
                              </span>
                              <span className="text-gray-500">•</span>
                              <span className="text-gray-500">
                                {new Date(msg.timestamp).toLocaleTimeString()}
                              </span>
                            </div>
                            <p className="text-gray-600 mt-1 truncate">{msg.message}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
          
          {!loading && rooms.length === 0 && (
            <div className="text-center py-8">
              <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">No rooms found</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}