import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { 
  Shield, 
  Plus, 
  Trash2, 
  MessageSquare, 
  Users, 
  Settings,
  AlertTriangle,
  Lock,
  Eye
} from 'lucide-react';

interface AdminPanelProps {
  currentRoomId: string;
}

export default function AdminPanel({ currentRoomId }: AdminPanelProps) {
  const [adminPassword, setAdminPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [newRoomData, setNewRoomData] = useState({
    id: '',
    name: '',
    description: '',
    isPrivate: false
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: rooms } = useQuery({
    queryKey: ['/api/rooms'],
    enabled: isAuthenticated,
  });

  const { data: messages } = useQuery({
    queryKey: ['/api/rooms', currentRoomId, 'messages'],
    enabled: isAuthenticated,
  });

  const verifyAdminMutation = useMutation({
    mutationFn: () => apiRequest('/api/admin/rooms', {
      method: 'POST',
      body: { password: adminPassword, id: 'test', name: 'test' }
    }),
    onSuccess: () => {
      setIsAuthenticated(true);
      toast({
        title: "Admin Access Granted",
        description: "You now have admin privileges",
      });
    },
    onError: () => {
      toast({
        title: "Access Denied",
        description: "Invalid admin password",
        variant: "destructive"
      });
    }
  });

  const createRoomMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/admin/rooms', {
      method: 'POST',
      body: { ...data, password: adminPassword }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rooms'] });
      setNewRoomData({ id: '', name: '', description: '', isPrivate: false });
      toast({
        title: "Room Created",
        description: "New room has been created successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create room",
        variant: "destructive"
      });
    }
  });

  const deleteRoomMutation = useMutation({
    mutationFn: (roomId: string) => apiRequest(`/api/admin/rooms/${roomId}`, {
      method: 'DELETE',
      body: { password: adminPassword }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rooms'] });
      toast({
        title: "Room Deleted",
        description: "Room has been deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete room",
        variant: "destructive"
      });
    }
  });

  const clearRoomMutation = useMutation({
    mutationFn: (roomId: string) => apiRequest(`/api/admin/rooms/${roomId}/clear`, {
      method: 'POST',
      body: { password: adminPassword }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rooms', currentRoomId, 'messages'] });
      toast({
        title: "Room Cleared",
        description: "All messages in this room have been cleared",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to clear room",
        variant: "destructive"
      });
    }
  });

  const deleteMessageMutation = useMutation({
    mutationFn: (messageId: number) => apiRequest(`/api/admin/messages/${messageId}`, {
      method: 'DELETE',
      body: { password: adminPassword }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rooms', currentRoomId, 'messages'] });
      toast({
        title: "Message Deleted",
        description: "Message has been deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete message",
        variant: "destructive"
      });
    }
  });

  const handleAuth = () => {
    // Test authentication by trying to access admin endpoint
    verifyAdminMutation.mutate();
  };

  if (!isAuthenticated) {
    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="bg-red-50 hover:bg-red-100 text-red-700 border-red-200">
            <Shield className="w-4 h-4 mr-2" />
            Admin
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-red-600" />
              <span>Admin Authentication</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="admin-password">Admin Password</Label>
              <Input
                id="admin-password"
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Enter admin password"
              />
            </div>
            <Button 
              onClick={handleAuth}
              disabled={verifyAdminMutation.isPending}
              className="w-full"
            >
              {verifyAdminMutation.isPending ? 'Verifying...' : 'Authenticate'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="bg-red-50 hover:bg-red-100 text-red-700 border-red-200">
          <Settings className="w-4 h-4 mr-2" />
          Admin Panel
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-red-600" />
            <span>Admin Panel</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Room Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Plus className="w-4 h-4" />
                <span>Create New Room</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="room-id">Room ID</Label>
                  <Input
                    id="room-id"
                    value={newRoomData.id}
                    onChange={(e) => setNewRoomData({...newRoomData, id: e.target.value})}
                    placeholder="unique-room-id"
                  />
                </div>
                <div>
                  <Label htmlFor="room-name">Room Name</Label>
                  <Input
                    id="room-name"
                    value={newRoomData.name}
                    onChange={(e) => setNewRoomData({...newRoomData, name: e.target.value})}
                    placeholder="Room Display Name"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="room-description">Description</Label>
                <Textarea
                  id="room-description"
                  value={newRoomData.description}
                  onChange={(e) => setNewRoomData({...newRoomData, description: e.target.value})}
                  placeholder="Room description..."
                  className="h-20"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="room-private"
                  checked={newRoomData.isPrivate}
                  onCheckedChange={(checked) => setNewRoomData({...newRoomData, isPrivate: checked})}
                />
                <Label htmlFor="room-private" className="flex items-center space-x-2">
                  <Lock className="w-4 h-4" />
                  <span>Private Room</span>
                </Label>
              </div>
              <Button 
                onClick={() => createRoomMutation.mutate(newRoomData)}
                disabled={createRoomMutation.isPending || !newRoomData.id || !newRoomData.name}
                className="w-full"
              >
                {createRoomMutation.isPending ? 'Creating...' : 'Create Room'}
              </Button>
            </CardContent>
          </Card>

          {/* Existing Rooms */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>Manage Rooms</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {rooms?.map((room: any) => (
                  <div key={room.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-2">
                        {room.isPrivate ? <Lock className="w-4 h-4 text-gray-500" /> : <Eye className="w-4 h-4 text-gray-500" />}
                        <span className="font-medium">{room.name}</span>
                        <span className="text-sm text-gray-500">({room.id})</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => clearRoomMutation.mutate(room.id)}
                        disabled={clearRoomMutation.isPending}
                      >
                        <MessageSquare className="w-4 h-4 mr-1" />
                        Clear Messages
                      </Button>
                      {room.id !== 'general' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteRoomMutation.mutate(room.id)}
                          disabled={deleteRoomMutation.isPending}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Message Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageSquare className="w-4 h-4" />
                <span>Message Management - {currentRoomId}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {messages?.map((message: any) => (
                  <div key={message.id} className="flex items-center justify-between p-2 bg-gray-50 rounded text-sm">
                    <div className="flex-1 min-w-0">
                      <span className="font-medium text-blue-600">{message.username}:</span>
                      <span className="ml-2 text-gray-700">{message.message}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteMessageMutation.mutate(message.id)}
                      disabled={deleteMessageMutation.isPending}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="flex items-center space-x-2 p-4 bg-yellow-50 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-yellow-600" />
            <span className="text-sm text-yellow-800">
              Admin actions are irreversible. Use with caution.
            </span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}