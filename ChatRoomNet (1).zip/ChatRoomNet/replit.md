# Overview

This is a real-time chat application built with React (frontend) and Express.js (backend), using WebSockets for real-time communication. The application supports multiple chat rooms and tracks active users. It uses in-memory storage for development, shadcn/ui components for the UI, and includes comprehensive TypeScript support throughout. The chat system is fully functional with user presence indicators, message history, and real-time messaging capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and building
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React hooks for local state, TanStack Query for server state
- **UI Components**: shadcn/ui component library based on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Real-time Communication**: WebSocket API for chat functionality

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Real-time Communication**: ws (WebSocket) library for bidirectional communication
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **Development**: tsx for TypeScript execution, hot reloading via Vite integration

## Data Storage
- **Database**: PostgreSQL (configured via DATABASE_URL environment variable)
- **ORM**: Drizzle ORM with schema-first approach
- **Migration**: Drizzle Kit for database schema management
- **Session Storage**: PostgreSQL-backed session storage
- **Fallback**: In-memory storage implementation for development/testing

# Key Components

## Database Schema
- **Users Table**: Stores user credentials (id, username, password)
- **Messages Table**: Stores chat messages (id, username, message, roomId, timestamp)
- **Schema Validation**: Zod schemas for runtime validation of data

## WebSocket Communication
- **Connection Management**: Tracks active connections per room
- **Message Types**: 
  - `join`: User joins a room
  - `message`: Send/receive chat messages
  - `disconnect`: User leaves a room
- **Real-time Features**: Live user count, message broadcasting, connection status

## UI Components
- **Chat Interface**: Message display, input field, user count, connection status
- **Room Management**: Support for multiple chat rooms (default: "general")
- **Responsive Design**: Mobile-friendly layout with Tailwind CSS
- **Toast Notifications**: User feedback for connection events

## Storage Layer
- **Interface**: IStorage interface for pluggable storage backends
- **Implementations**: 
  - PostgreSQL storage (primary)
  - In-memory storage (development/fallback)
- **Operations**: User management, message persistence, active user tracking

# Data Flow

## User Journey
1. User enters username and room ID
2. WebSocket connection established to `/ws` endpoint
3. User joins room, receives message history
4. Real-time message exchange with other users
5. Live updates for user count and connection status

## Message Flow
1. User types message in input field
2. Message sent via WebSocket to server
3. Server validates and stores message in database
4. Server broadcasts message to all users in the same room
5. All clients receive and display the message

## Connection Management
1. WebSocket connection tracks username and room
2. Server maintains active user list per room
3. User count updated in real-time
4. Connection status displayed to users

# External Dependencies

## Frontend Dependencies
- **React Ecosystem**: React, React DOM, React Query
- **UI Framework**: Radix UI primitives, shadcn/ui components
- **Styling**: Tailwind CSS, class-variance-authority for component variants
- **Utilities**: date-fns for date formatting, clsx for conditional classes
- **Development**: Vite, TypeScript, ESLint

## Backend Dependencies
- **Server**: Express.js, ws for WebSocket support
- **Database**: Drizzle ORM, @neondatabase/serverless for PostgreSQL
- **Session**: connect-pg-simple for session management
- **Validation**: Zod for schema validation
- **Development**: tsx for TypeScript execution, esbuild for production builds

## Development Tools
- **Build**: Vite for frontend, esbuild for backend
- **Database**: Drizzle Kit for migrations and schema management
- **TypeScript**: Full TypeScript support with path mapping
- **Replit Integration**: Specialized plugins for Replit environment

# Deployment Strategy

## Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: esbuild compiles TypeScript server to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command
- **Static Files**: Express serves built frontend files in production

## Development Environment
- **Hot Reloading**: Vite middleware integrated with Express server
- **Database**: PostgreSQL connection via DATABASE_URL environment variable
- **WebSocket**: Same port as HTTP server for simplified development
- **TypeScript**: tsx provides direct TypeScript execution

## Environment Configuration
- **Database**: Requires DATABASE_URL for PostgreSQL connection
- **Session**: PostgreSQL-backed session storage
- **Development**: NODE_ENV controls development/production behavior
- **Port**: Server runs on configurable port (default from environment)

## Scalability Considerations
- **Database**: PostgreSQL provides ACID compliance and scalability
- **WebSocket**: Single server instance, consider clustering for scale
- **Session Storage**: PostgreSQL-backed sessions support horizontal scaling
- **Static Assets**: Frontend built as static files for CDN deployment