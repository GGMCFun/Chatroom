import { users, messages, rooms, type User, type InsertUser, type Message, type InsertMessage, type Room, type InsertRoom } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createMessage(message: InsertMessage): Promise<Message>;
  getMessages(roomId: string, limit?: number): Promise<Message[]>;
  getActiveUsers(roomId: string): Promise<string[]>;
  addUserToRoom(username: string, roomId: string): Promise<void>;
  removeUserFromRoom(username: string, roomId: string): Promise<void>;
  // Room management
  createRoom(room: InsertRoom): Promise<Room>;
  getRoom(id: string): Promise<Room | undefined>;
  getRooms(): Promise<Room[]>;
  deleteRoom(id: string): Promise<void>;
  // Message management
  deleteMessage(id: number): Promise<void>;
  clearRoomMessages(roomId: string): Promise<void>;
  getMessageCount(roomId: string): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messages: Map<number, Message>;
  private rooms: Map<string, Room>;
  private activeUsers: Map<string, Set<string>>; // roomId -> Set of usernames
  private currentUserId: number;
  private currentMessageId: number;

  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.rooms = new Map();
    this.activeUsers = new Map();
    this.currentUserId = 1;
    this.currentMessageId = 1;
    
    // Create default rooms
    this.rooms.set('general', {
      id: 'general',
      name: 'General',
      description: 'Default chat room',
      isPrivate: false,
      createdAt: new Date(),
    });
    
    this.rooms.set('random', {
      id: 'random',
      name: 'Random',
      description: 'Random discussions',
      isPrivate: false,
      createdAt: new Date(),
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createMessage(insertMessage: InsertMessage & { isAdmin?: boolean }): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      ...insertMessage,
      id,
      roomId: insertMessage.roomId || 'general',
      timestamp: new Date(),
      isAdmin: insertMessage.isAdmin || false,
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessages(roomId: string, limit: number = 50): Promise<Message[]> {
    const roomMessages = Array.from(this.messages.values())
      .filter(msg => msg.roomId === roomId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
      .slice(-limit);
    
    return roomMessages;
  }

  async getActiveUsers(roomId: string): Promise<string[]> {
    const users = this.activeUsers.get(roomId);
    return users ? Array.from(users) : [];
  }

  async addUserToRoom(username: string, roomId: string): Promise<void> {
    if (!this.activeUsers.has(roomId)) {
      this.activeUsers.set(roomId, new Set());
    }
    this.activeUsers.get(roomId)!.add(username);
  }

  async removeUserFromRoom(username: string, roomId: string): Promise<void> {
    const users = this.activeUsers.get(roomId);
    if (users) {
      users.delete(username);
      if (users.size === 0) {
        this.activeUsers.delete(roomId);
      }
    }
  }

  // Room management methods
  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const room: Room = {
      ...insertRoom,
      description: insertRoom.description || null,
      isPrivate: insertRoom.isPrivate || false,
      createdAt: new Date(),
    };
    this.rooms.set(room.id, room);
    return room;
  }

  async getRoom(id: string): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async getRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values());
  }

  async deleteRoom(id: string): Promise<void> {
    this.rooms.delete(id);
    // Also remove all messages from this room
    const roomMessages = Array.from(this.messages.entries())
      .filter(([_, msg]) => msg.roomId === id);
    roomMessages.forEach(([id, _]) => this.messages.delete(id));
    // Remove active users from this room
    this.activeUsers.delete(id);
  }

  // Message management methods
  async deleteMessage(id: number): Promise<void> {
    this.messages.delete(id);
  }

  async clearRoomMessages(roomId: string): Promise<void> {
    const roomMessages = Array.from(this.messages.entries())
      .filter(([_, msg]) => msg.roomId === roomId);
    roomMessages.forEach(([id, _]) => this.messages.delete(id));
  }

  async getMessageCount(roomId: string): Promise<number> {
    return Array.from(this.messages.values())
      .filter(message => message.roomId === roomId).length;
  }
}

export const storage = new MemStorage();
