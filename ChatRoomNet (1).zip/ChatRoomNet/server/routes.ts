import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertMessageSchema, insertRoomSchema } from "@shared/schema";
import { z } from "zod";

const ADMIN_PASSWORD = "Admin12";

interface WebSocketClient extends WebSocket {
  username?: string;
  roomId?: string;
  isAdmin?: boolean;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server on distinct path
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store active connections
  const clients = new Map<string, WebSocketClient>();

  // WebSocket connection handler
  wss.on('connection', (ws: WebSocketClient) => {
    console.log('New WebSocket connection');

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        switch (message.type) {
          case 'join':
            await handleJoin(ws, message, clients);
            break;
          case 'message':
            await handleMessage(ws, message, clients);
            break;
          case 'disconnect':
            await handleDisconnect(ws, clients);
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format'
        }));
      }
    });

    ws.on('close', () => {
      handleDisconnect(ws, clients);
    });
  });

  async function handleJoin(ws: WebSocketClient, message: any, clients: Map<string, WebSocketClient>) {
    const { username, roomId = 'general', adminPassword } = message;
    
    console.log('Join request:', { username, roomId, adminPassword: adminPassword ? '[PROVIDED]' : '[EMPTY]' });
    
    if (!username || username.trim().length === 0) {
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Username is required'
      }));
      return;
    }

    // Create room if it doesn't exist
    let room = await storage.getRoom(roomId);
    if (!room) {
      room = await storage.createRoom({
        id: roomId,
        name: roomId.charAt(0).toUpperCase() + roomId.slice(1),
        description: `Room ${roomId}`,
        isPrivate: false
      });
    }

    // Check if username is already taken in the room
    const activeUsers = await storage.getActiveUsers(roomId);
    if (activeUsers.includes(username)) {
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Username already taken in this room'
      }));
      return;
    }

    // Check if user is admin
    const isAdmin = adminPassword === ADMIN_PASSWORD;
    console.log('Admin check:', { adminPassword, expectedPassword: ADMIN_PASSWORD, isAdmin });

    // Set client info
    ws.username = username;
    ws.roomId = roomId;
    ws.isAdmin = isAdmin;
    
    // Add to active users
    await storage.addUserToRoom(username, roomId);
    
    // Store client connection
    const clientKey = `${username}:${roomId}`;
    clients.set(clientKey, ws);

    // Get message history
    const messageHistory = await storage.getMessages(roomId);
    
    // Send join success with message history
    ws.send(JSON.stringify({
      type: 'joined',
      username,
      roomId,
      messages: messageHistory,
      userCount: (await storage.getActiveUsers(roomId)).length,
      isAdmin
    }));

    // Notify other users in the room
    broadcastToRoom(roomId, {
      type: 'user_joined',
      username,
      userCount: (await storage.getActiveUsers(roomId)).length,
      isAdmin
    }, clients, username);

    console.log(`User ${username} joined room ${roomId}${isAdmin ? ' (Admin)' : ''}`);
  }

  async function handleMessage(ws: WebSocketClient, message: any, clients: Map<string, WebSocketClient>) {
    if (!ws.username || !ws.roomId) {
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Must join a room first'
      }));
      return;
    }

    // Check for admin commands
    if (message.message.trim() === '/clear' && ws.isAdmin) {
      // Clear all messages in the room
      await storage.clearRoomMessages(ws.roomId);
      
      // Broadcast clear message to all users in the room
      broadcastToRoom(ws.roomId, {
        type: 'messages_cleared',
        adminUsername: ws.username
      }, clients);
      
      console.log(`Admin ${ws.username} cleared messages in room ${ws.roomId}`);
      return;
    }

    try {
      const validatedMessage = insertMessageSchema.parse({
        username: ws.username,
        message: message.message,
        roomId: ws.roomId
      });

      // Store message with admin flag
      const savedMessage = await storage.createMessage({
        ...validatedMessage,
        isAdmin: ws.isAdmin || false
      });

      // Broadcast to all users in the room
      broadcastToRoom(ws.roomId, {
        type: 'message',
        id: savedMessage.id,
        username: savedMessage.username,
        message: savedMessage.message,
        roomId: savedMessage.roomId,
        timestamp: savedMessage.timestamp,
        isAdmin: savedMessage.isAdmin || false
      }, clients);

      console.log(`Message from ${ws.username} in ${ws.roomId}: ${message.message}`);
    } catch (error) {
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Invalid message format'
      }));
    }
  }

  async function handleDisconnect(ws: WebSocketClient, clients: Map<string, WebSocketClient>) {
    if (ws.username && ws.roomId) {
      // Remove from active users
      await storage.removeUserFromRoom(ws.username, ws.roomId);
      
      // Remove from clients
      const clientKey = `${ws.username}:${ws.roomId}`;
      clients.delete(clientKey);

      // Notify other users
      broadcastToRoom(ws.roomId, {
        type: 'user_left',
        username: ws.username,
        userCount: (await storage.getActiveUsers(ws.roomId)).length
      }, clients, ws.username);

      console.log(`User ${ws.username} left room ${ws.roomId}`);
    }
  }

  function broadcastToRoom(roomId: string, message: any, clients: Map<string, WebSocketClient>, excludeUsername?: string) {
    const messageStr = JSON.stringify(message);
    
    clients.forEach((client, key) => {
      const [username, clientRoomId] = key.split(':');
      
      if (clientRoomId === roomId && 
          client.readyState === WebSocket.OPEN && 
          username !== excludeUsername) {
        client.send(messageStr);
      }
    });
  }

  // Admin middleware
  const verifyAdmin = (req: any, res: any, next: any) => {
    const { password } = req.body;
    if (password !== ADMIN_PASSWORD) {
      return res.status(401).json({ error: 'Invalid admin password' });
    }
    next();
  };

  // REST API endpoints
  app.get('/api/rooms/:roomId/messages', async (req, res) => {
    try {
      const { roomId } = req.params;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const messages = await storage.getMessages(roomId, limit);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  app.get('/api/rooms/:roomId/users', async (req, res) => {
    try {
      const { roomId } = req.params;
      const users = await storage.getActiveUsers(roomId);
      res.json({ users, count: users.length });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });

  app.get('/api/rooms', async (req, res) => {
    try {
      const rooms = await storage.getRooms();
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch rooms' });
    }
  });

  // Get all rooms with user counts and messages (admin only)
  app.get('/api/admin/rooms', async (req, res) => {
    try {
      const rooms = await storage.getRooms();
      const roomsWithDetails = await Promise.all(
        rooms.map(async (room) => {
          const activeUsers = await storage.getActiveUsers(room.id);
          const messages = await storage.getMessages(room.id, 10); // Get last 10 messages
          const totalMessages = await storage.getMessageCount(room.id);
          return {
            ...room,
            userCount: activeUsers.length,
            activeUsers,
            recentMessages: messages,
            totalMessages
          };
        })
      );
      res.json(roomsWithDetails);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch rooms' });
    }
  });

  // Admin endpoints
  app.post('/api/admin/rooms', verifyAdmin, async (req, res) => {
    try {
      const { id, name, description, isPrivate } = req.body;
      const roomData = insertRoomSchema.parse({ id, name, description, isPrivate });
      
      const existingRoom = await storage.getRoom(id);
      if (existingRoom) {
        return res.status(400).json({ error: 'Room already exists' });
      }
      
      const room = await storage.createRoom(roomData);
      res.json(room);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create room' });
    }
  });

  app.delete('/api/admin/rooms/:roomId', verifyAdmin, async (req, res) => {
    try {
      const { roomId } = req.params;
      if (roomId === 'general') {
        return res.status(400).json({ error: 'Cannot delete general room' });
      }
      
      await storage.deleteRoom(roomId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete room' });
    }
  });

  app.post('/api/admin/rooms/:roomId/clear', verifyAdmin, async (req, res) => {
    try {
      const { roomId } = req.params;
      await storage.clearRoomMessages(roomId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to clear room messages' });
    }
  });

  app.delete('/api/admin/messages/:messageId', verifyAdmin, async (req, res) => {
    try {
      const { messageId } = req.params;
      await storage.deleteMessage(parseInt(messageId));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete message' });
    }
  });

  return httpServer;
}
